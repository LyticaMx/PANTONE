# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pantone']

package_data = \
{'': ['*']}

install_requires = \
['opencv-contrib-python>=4.5.5,<5.0.0', 'scikit-learn>=1.0.2,<2.0.0']

setup_kwargs = {
    'name': 'pantone',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Celeste Villaverde',
    'author_email': 'celeste.villaverde@springlabs.net',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<3.11',
}


setup(**setup_kwargs)
